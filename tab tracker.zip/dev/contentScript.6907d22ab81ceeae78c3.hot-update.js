webpackHotUpdate("contentScript",{

/***/ "./src/contentScript/index.ts":
/*!************************************!*\
  !*** ./src/contentScript/index.ts ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Upload; });
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
/* harmony import */ var _firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../firebase */ "./src/firebase.js");
// If your extension doesn't need a content script, just leave this file empty

 // This is an example of a script that will run on every page. This can alter pages
// Don't forget to change `matches` in manifest.json if you want to only change specific webpages
// printAllPageLinks();
// This needs to be an export due to typescript implementation limitation of needing '--isolatedModules' tsconfig

setTimeout(Upload(), 5000);
async function Upload() {
  const date = new Date();
  const email = await localStorage.getItem('email');
  const myemail = _firebase__WEBPACK_IMPORTED_MODULE_1__["auth"].currentUser;
  const dt = date.toLocaleDateString() + "  " + date.toLocaleTimeString();
  console.log("email : ", email);
  console.log("my email : ", myemail);
  const url = window.location.href;
  console.log(url);
  chrome.tabs.query({
    currentWindow: true,
    active: true
  }, function (tabs) {
    const url = tabs[0].url;
    console.log("url : ", url);

    try {
      Object(firebase_firestore__WEBPACK_IMPORTED_MODULE_0__["addDoc"])(Object(firebase_firestore__WEBPACK_IMPORTED_MODULE_0__["collection"])(_firebase__WEBPACK_IMPORTED_MODULE_1__["db"], email), {
        url: url,
        datetime: dt
      });
      console.log("Uploaded");
    } catch (error) {
      alert(error);
      console.log("Not Uploaded");
    }
  });
}

/***/ })

})
//# sourceMappingURL=contentScript.6907d22ab81ceeae78c3.hot-update.js.map